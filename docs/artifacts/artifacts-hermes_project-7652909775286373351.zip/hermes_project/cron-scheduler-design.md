# Hermes 统一调度框架设计

> 用于替代现有脚本中散落的 `apscheduler` / cron / 手动 sleep 循环，把所有"定时任务型"作业收口到单一调度器。

## 1. 问题根因

| 当前现象 | 后果 |
|---------|------|
| 10 个脚本中 4 个是定时任务型（`daily-learn` / `memory-cleanup` / `system-health-check` / `clustering-analysis-v3`） | 调度逻辑分散，无法统一管理 |
| 每个脚本自带调度代码 + 自定义失败处理 | 失败告警、重试、互斥语义各不一致 |
| 任务之间的**依赖与互斥靠约定**（"我记得 memory-cleanup 和 daily-learn 不能同时跑"） | 偶发撞车，无明确告警 |
| 没有**任务运行状态**统一视图 | 出问题靠人肉翻日志 |
| 没有**幂等保证** | 同一窗口内重跑可能产生脏数据 |

## 2. 设计目标

- **单一调度入口**：`hermes-scheduler` 拉起所有定时任务，脚本不再自带 cron
- **任务声明化**：用 YAML 描述"做什么 / 何时跑 / 依赖谁 / 失败怎么办"
- **依赖与互斥显式声明**：写在配置里，调度器自动 enforce
- **幂等是硬性约束**：所有任务必须能在同一窗口安全重跑
- **状态可观测**：任务状态、执行历史、失败原因存 PG，统一查询
- **可独立测试**：每个任务可被 CLI 手动触发并 mock 输入

## 3. 核心架构

```
┌────────────────────┐
│ hermes-scheduler   │  ← 单进程主调度器（APScheduler + 持久化）
│   (主循环)         │
└─────────┬──────────┘
          │ 读取任务声明
          ▼
┌────────────────────┐
│ tasks/*.yaml       │  ← 任务声明仓库（Git 管理）
│  + registry API    │
└─────────┬──────────┘
          │ 触发时
          ▼
┌────────────────────┐
│ Task Worker Pool   │  ← 独立 worker 进程（隔离 + 并发）
│   (N 个 worker)    │
└─────────┬──────────┘
          │ 写状态
          ▼
┌────────────────────┐
│ shared-postgres    │  ← 任务状态、执行历史、advisory lock
│  - scheduler_jobs  │
│  - scheduler_runs  │
│  - scheduler_locks │
└────────────────────┘
          │ 失败时
          ▼
┌────────────────────┐
│ Alert Sink         │  ← 飞书群机器人 / webhook
└────────────────────┘
```

## 4. 任务声明 Schema

```yaml
# tasks/memory-cleanup.daily.yaml
id: memory-cleanup.daily          # 唯一 ID
description: "Hindsight 去重 / 纠错 / 合并"
owner: "myHermes"

schedule:
  cron: "0 3 * * *"               # 每天凌晨 3 点
  timezone: "Asia/Shanghai"
  jitter_seconds: 60              # 抖动，避免多任务齐点触发

runtime:
  entrypoint: "python -m hermes_tasks.memory_cleanup"  # 可执行入口
  timeout_seconds: 1800           # 30 分钟硬超时
  working_dir: "/root/.hermes/scripts/memory-cleanup/"

dependencies:
  requires:                       # 前置健康检查
    - id: hindsight-index.healthy
      check: "http://hindsight:8080/healthz"
      timeout: 30
  data_ready:                     # 数据就绪
    - type: "pg_count"
      sql: "SELECT COUNT(*) FROM hindsight_facts WHERE ts > now() - interval '1 day'"
      min: 1

mutex:                            # 互斥组（同一时间只跑一个）
  - "nightly-maintenance"
  - "hindsight-write"

retry:
  max_attempts: 2
  backoff: exponential            # 2/4/8 分钟
  on_exhausted: alert_critical    # 重试耗尽 → 关键告警

idempotency:
  strategy: "pg-advisory-lock"    # 用 PG advisory lock 锁住 (job_id, time_bucket)
  bucket: "1d"                    # 同一天重跑视为同一窗口

artifacts:
  on_success: "save_to:pg"        # 结果写回 PG
  on_failure: "save_log:pg"

alerts:
  on_start: false
  on_success: false
  on_failure: alert_warning
  on_timeout: alert_critical
  on_lock_conflict: silent        # 互斥冲突静默
```

## 5. 关键设计决策

| 决策点 | 选择 | 理由 |
|--------|------|------|
| 调度器内核 | APScheduler（持久化到 PG） | 轻量、Python 生态、足够支撑单实例 |
| 任务隔离 | 独立 worker 进程 | 防止一个任务 OOM 拖垮全部 |
| 互斥实现 | PG advisory lock | 不需要额外组件、原子性强 |
| 幂等性 | **硬性约束**，所有任务必须声明幂等策略 | 重跑是常态，不能靠人肉判断 |
| 任务发现 | YAML 声明 + 自动注册 | 不需要在代码里 hardcode |
| 失败告警 | 飞书群机器人 webhook | 已有通道 |
| 健康检查 | HTTP 探活 / PG 数据探活 | 简单、可声明 |
| 分布式 | 单实例先跑，预留 leader 选举位 | 当前规模不需要 HA |
| 任务超时 | 调度器 SIGTERM → 升级 SIGKILL | 防止僵尸 worker |

## 6. 与现有系统的边界

| 系统 | 职责 |
|------|------|
| **部署系统** | 管"装"——把代码装到 `/root/.hermes/` |
| **统一调度器（本设计）** | 管"跑"——什么时候跑、跑什么、失败怎么办 |
| **记忆系统** | 管"存"——Hindsight 数据怎么持久化、索引 |
| **知识系统** | 管"用"——召回、注入、生成 |

四者解耦：部署系统装好代码后，统一调度器才能发现并调度它。

## 7. 迁移路径

| Phase | 工作量 | 内容 |
|-------|--------|------|
| **Phase 1** | 1 周 | 写 `hermes-scheduler` 核心（声明解析 + 调度 + worker 池 + 状态表） |
| **Phase 2** | 1 周 | 把 `system-health-check` 包装成第一个任务 |
| **Phase 3** | 2 周 | 迁移 `daily-learn` / `memory-cleanup` / `clustering-analysis-v3` |
| **Phase 4** | 1 周 | 接入告警 + 状态面板（CLI `hermes-scheduler status`） |
| **Phase 5** | 持续 | 废弃脚本内嵌 cron 配置、加新任务只需写 YAML |

## 8. 不做

- ❌ 不做分布式 leader 选举（当前规模不需要）
- ❌ 不做任务 DAG 编排（依赖是线性的，APScheduler 够用）
- ❌ 不做可视化拖拽（YAML + CLI 即可）
- ❌ 不做任务参数版本管理（用 Git 管 YAML 即可）

## 9. 验证标准

- 所有定时任务从脚本迁移到调度器
- 调度器内可看到所有任务状态、运行历史、失败原因
- 同一窗口内重跑任意任务不会产生脏数据
- 任意两个互斥任务不会同时执行
- 单任务失败不影响其他任务
- `hermes-scheduler status` 一行命令即可总览

---

## 附：典型迁移对比

**Before**（脚本内嵌 cron）：
```python
# daily-learn/main.py
from apscheduler.schedulers.blocking import BlockingScheduler
sched = BlockingScheduler()
sched.add_job(run_daily_learn, 'cron', hour=3)
sched.start()
```

**After**（任务声明）：
```yaml
# tasks/daily-learn.daily.yaml
id: daily-learn.daily
schedule: { cron: "0 3 * * *", timezone: "Asia/Shanghai" }
runtime: { entrypoint: "python -m hermes_tasks.daily_learn" }
```

调度器自动发现、自动跑、出问题自动告警。
